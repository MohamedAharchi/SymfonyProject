<?php
// src/OC/PlatformBundle/Purger/PurgerAdvert.php

namespace OC\PlatformBundle\Purger;

use OC\PlatformBundle\Entity\Advert;
use OC\PlatformBundle\Entity\Application;
use OC\PlatformBundle\Respository\AdvertRepository;

class PurgerAdvert
{
  private $listAdverst;
  private $date; 
  private $em;

  public function __construct($doctrine) 
  {
    $this->date = new \DateTime();
    $this->em = $doctrine->getManager(); 
  }

  public function purge($days) 
  {
    $dateDiff = $this->date->modify('- '.$days.' day');
    $listAdverts = $this->em
      ->getRepository('OCPlatformBundle:Advert')
      ->getAdvertsWithoutApp($dateDiff)
    ;

    $advertsToBeRemove = array();
    foreach ($listAdverts as $advert) {
      //$this->$em->remove($advert);
      $advertsToBeRemove[] = $advert->getId();
    }
    $this->em->getRepository('OCPlatformBundle:Advert')->removeListAdverts($advertsToBeRemove);
    //$this->$em->flush();
  }
}
